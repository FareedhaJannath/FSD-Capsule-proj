import { Component, OnInit, OnDestroy, DoCheck } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from "@angular/forms";

import { Category } from "../../services/model";
import { AlertService } from '../alert/alert.service';
import { WorkoutService } from "../../services/workout.service";

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  categoryForm: FormGroup;
  categoryText: string;
  categoryList: Category[]=[];
  category: Category;
  submitted: boolean = false;
  
  constructor(public route: ActivatedRoute,
        public router: Router,
        public workoutService: WorkoutService,
        public formBuilder: FormBuilder,
        public alertService: AlertService)
         { 
          this.getCategories();
        }

  ngOnInit() {
      this.categoryForm = new FormGroup({
        searchCategory: new FormControl('', [<any>Validators.required, <any>Validators.minLength(5)]),
        title: new FormControl('', [<any>Validators.required, <any>Validators.minLength(5)])
    });


  }
   
 /*removeCategory(category: Category, index:number){
         this.categoryList.splice(index, 1);
    }*/

    deleteCategory(deleteCategory:Category) {
        const status = this.workoutService.deleteCategory(deleteCategory.title);
        // console.log('delete..'+status);
        
         if(status) {
            this.alertService.addAlert('Category deleted successfully..!!', 'success');
            this.getCategories();
          }
    }

     editCategory(category,idx){
       // console.log('update..'+category.title+' '+idx);
        const status = this.workoutService.updateCategory(category,idx);
        if(status){ 
          this.alertService.addAlert('Category updated successfully..!!', 'success');
        }
        console.log(status);
    }
   
   getCategories(): void {
    this.categoryList = new Array<Category>();
    this.workoutService.getCategories().forEach(category => {
      this.categoryList.push(new Category(category.title, false));
    });
  }
   
   onAddClick(title: string) : void{
         // console.log(title);
          let category = new Category(title, false);
          let status=false;
          if(title && title.length>0) {
            status = this.workoutService.addCategory(category);
            this.getCategories();
          }
          else
          {
            // invalid request
          }
          title='';
   }
   mapFormValues(form: FormGroup) {
        this.category.title = form.controls['title'].value;
    }

  onSubmit(categoryForm: FormGroup) {
        this.submitted = true;
        if (!categoryForm.valid) return;
        this.mapFormValues(categoryForm);
       // this.exerciseBuilderService.save();
        //this.router.navigate(['/builder/exercises']);
    }
}
