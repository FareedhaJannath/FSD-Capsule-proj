import { Component, OnInit, OnDestroy, DoCheck } from '@angular/core';
import {DatePipe} from '@angular/common';
import { ActivatedRoute, Router } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from "@angular/forms";

import { WorkOut, DailyWorkoutPlan } from "../../services/model";
import { WorkoutService } from "../../services/workout.service";
import { AlertService } from "../alert/alert.service";
import {TimerComponent} from '../timer/timer.component';

@Component({
  selector: 'app-view-workout',
  templateUrl: './view-workout.component.html',
  styleUrls: ['./view-workout.component.css']
})
export class ViewWorkoutComponent implements OnInit {

    workouts: Array<WorkOut>;
    date: Date;
    timeComp: TimerComponent;
    showStartDailyWorkout:boolean;
    dailyWorkout:DailyWorkoutPlan;
    comment:string;
    startDate:string;
    endDate:string;
    startTime:string;
    endTime:string;
    
    constructor(
        public route: ActivatedRoute,
        public router: Router,
        public workoutService: WorkoutService,
        public formBuilder: FormBuilder,
        public alertService: AlertService,
        public datePipe:DatePipe
         ) { 
        this.getWorkouts();
        this.showStartDailyWorkout=false;
        this.comment='';
        this.startDate=this.datePipe.transform(new Date(),'yyyy-MM-dd');
        this.endDate=this.datePipe.transform(new Date(),'yyyy-MM-dd');
        this.startTime=this.datePipe.transform(new Date(),'hh:mm:ss');
        this.endTime=this.datePipe.transform(new Date(),'hh:mm:ss');;
    }

    ngOnInit(): any {
     }
    
    getWorkouts() : void {
      this.workouts  = this.workoutService.getWorkouts();
      //console.log(this.workouts);
    }
    
    deleteWorkout(idx: number): void {
    const status = this.workoutService.deleteWorkout(idx);
    if(status) {
      this.alertService.addAlert('Workout deleted successfully..!!', 'success');
      this.workouts = this.workoutService.getWorkouts();
    }
  }

    startDailyWorkout(idx:number){
     // this.dailyWorkout.workoutId=this.workouts[idx].workoutId;
     let workouts:Array<WorkOut> = this.workoutService.getWorkouts();
     let workout = workouts[idx];
     let currentWorkout:Array<WorkOut> = new Array<WorkOut>();
     currentWorkout.push(workout);
      
     this.dailyWorkout = {comment:this.comment,
                          startDate:this.startDate,
                          endDate:this.endDate,
                          startTime:this.startTime,
                          endTime:this.endTime,
                          status:'Y',
                          workout:currentWorkout,
                          workoutId:idx,
                          dailyWorkoutId:idx};
      this.showStartDailyWorkout=true;
      //console.log(this.dailyWorkout);
    }

    stopWorkout(comment:string){
      this.dailyWorkout.comment =comment;
      this.dailyWorkout.endDate= this.datePipe.transform(new Date(),'yyyy-MM-dd');
      this.dailyWorkout.endTime = this.datePipe.transform(new Date(),'hh:mm:ss');
      this.showStartDailyWorkout=false;
      //console.log('stop..'+JSON.stringify(this.dailyWorkout));
        const status = this.workoutService.saveDailyWorkout(this.dailyWorkout);
        this.comment='';
        this.startDate=this.datePipe.transform(new Date(),'yyyy-MM-dd');
        this.endDate=this.datePipe.transform(new Date(),'yyyy-MM-dd');
        this.startTime=this.datePipe.transform(new Date(),'hh:mm:ss');
        this.endTime=this.datePipe.transform(new Date(),'hh:mm:ss');
    }

    cancelWorkout(){
        this.showStartDailyWorkout=false;
        this.comment='';
       this.comment='';
        this.startDate=this.datePipe.transform(new Date(),'yyyy-MM-dd');
        this.endDate=this.datePipe.transform(new Date(),'yyyy-MM-dd');
        this.startTime=this.datePipe.transform(new Date(),'hh:mm:ss');
        this.endTime=this.datePipe.transform(new Date(),'hh:mm:ss');
    }

}
