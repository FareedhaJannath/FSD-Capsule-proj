import { Component, OnInit, OnDestroy, DoCheck } from '@angular/core';
import { ActivatedRoute, Router,Params } from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from "@angular/forms";
import { WorkoutService } from "../../services/workout.service";
import { AlertService } from '../alert/alert.service';
import { Category,WorkOut } from "../../services/model";

@Component({
  selector: 'app-create-workout',
  templateUrl: './create-workout.component.html',
  styleUrls: ['./create-workout.component.css']
})
export class CreateWorkoutComponent implements OnInit {

  workoutForm: FormGroup;
  categories: Category[]=[];
  category: Category;
  submitted: boolean;
  editedId: number =0;
  edited: boolean;
  workout: WorkOut;

  constructor(public route: ActivatedRoute,
        public router: Router,
        public workoutService: WorkoutService,
        public formBuilder: FormBuilder,
        public alertService: AlertService) { 
          this.categories = this.workoutService.getCategories();
           // subscribe to router event
          this.route.params.subscribe((params: Params) => {
        this.editedId = +params['workoutId'];
        if(this.editedId>=0){
          this.workout = this.workoutService.getWorkouts()[this.editedId];
          console.log(this.workout);
          this.createEditedForm();
        }
         console.log(this.editedId);
      });
    }

  ngOnInit() {
     if(this.editedId>=0){
        this.createEditedForm();
        this.edited=true;
     }else{
       this.createForm();
       this.edited=false;
     }

  }

  createForm(){
         this.workoutForm = new FormGroup({
            title: new FormControl('', [<any>Validators.required, <any>Validators.minLength(5)]),
            note: new FormControl('', [<any>Validators.required, <any>Validators.minLength(5)]),
            caloriesBurnt: new FormControl(0, [<any>Validators.required, Validators.min(0.1)]),
            category:new FormControl('', [<any>Validators.required, <any>Validators.minLength(3)])
    });
  }

 createEditedForm() {
    this.workoutForm = this.formBuilder.group({
      title: [{value: this.workout.title, disabled: true}],
      note: [this.workout.note],
      category: [this.workout.category, Validators.required]
    });
  }

  addCategory() : void{ 
     this.router.navigate(['workout/category']);
   }

    incrementCalories(): void {
    const calories = parseFloat(this.workoutForm.controls['caloriesBurnt'].value) + 0.1;
    this.workoutForm.controls['caloriesBurnt'].setValue(calories.toFixed(1));
  }

  decrementCalories(): void {
    const calories = parseFloat(this.workoutForm.controls['caloriesBurnt'].value) - 0.1;
    if(calories >= 0.0) {
      this.workoutForm.controls['caloriesBurnt'].setValue(calories.toFixed(1));
    }
    
  }

  saveWorkout(workout: WorkOut, isValid: boolean){
     this.submitted = true; 
    console.log(isValid);
    if(isValid) {
      const status = this.workoutService.saveWorkout(workout);
      if(status) {
        this.alertService.addAlert('Workout created successfully..!!', 'success');
        this.workoutForm.reset();
        this.submitted = false; 
      } else {
        // invalid
      }
    }
  }

  updateWorkout(workout: WorkOut, isValid: boolean,idx:number){
     this.submitted = true; 
    console.log(isValid);
    if(isValid) {
      workout.caloriesBurnt = this.workout.caloriesBurnt;
      workout.title=this.workout.title;
     const status = this.workoutService.updateWorkout(workout,idx);
      if(status) {
        this.alertService.addAlert('Workout updated successfully..!!', 'success');
        this.workoutForm.reset();
        this.submitted = false; 
      } else {
        // invalid
      }
    }
  }

  
  }

