import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { LocalStorage } from './local-storage';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/toPromise';

import { DailyWorkoutPlan, WorkOut, Category } from './model';
const SUCCESS = true;
const ERROR = false;

@Injectable()
export class WorkoutService{
    viewWorkouts: Array<DailyWorkoutPlan> = [];
    workouts: Array<WorkOut> = [];
    categories: Array<Category> =[];
    private clock: Observable<Date>;
    eventDate:Date = new Date();

    private diff: number;
    private countDownResult: number;
    private hours: number;
    private minutes: number;
    private seconds: number;

    constructor(public http: Http) {
        this.clock = Observable.interval(1000).map(tick => new Date()).share();
         Observable.interval(1000).map((x) => {
                this.diff = Math.floor((this.eventDate.getTime()- new Date().getTime()) / 1000);
            }).subscribe((x) => {           
                this.hours = this.getHours(this.diff);
                this.minutes = this.getMinutes(this.diff);
                this.seconds = this.getSeconds(this.diff);
            });
    }

      getHours(t){
        var days, hours;
        days = Math.floor(t / 86400);
        t -= days * 86400;
        hours = Math.floor(t / 3600) % 24;

        return hours;
    }

    getMinutes(t){
        var days, hours, minutes;
        days = Math.floor(t / 86400);
        t -= days * 86400;
        hours = Math.floor(t / 3600) % 24;
        t -= hours * 3600;
        minutes = Math.floor(t / 60) % 60;

        return minutes;
    }

    getSeconds(t){
        var days, hours, minutes, seconds;
        days = Math.floor(t / 86400);
        t -= days * 86400;
        hours = Math.floor(t / 3600) % 24;
        t -= hours * 3600;
        minutes = Math.floor(t / 60) % 60;
        t -= minutes * 60;
        seconds = t % 60;

        return seconds;
    }


     getClock(): Observable<Date> {
         return this.clock;
     }
    getDiff():number{
        return this.diff;
    }

    getCategories() {
        const categoryExist = localStorage.getItem('categories');
        if(null !=categoryExist){
            this.categories = JSON.parse(categoryExist);
        }
        return this.categories;
        //return this.http.get("/workout/category")
        //    .map((res: Response) => <Category[]>res.json())
         //   .catch(WorkoutService.handleError);
    }
    getCategory(categoryName: string) {
        return this.http.get('/workout/category' + categoryName)
            .map((res: Response) => <Category>res.json())
            .catch(WorkoutService.handleError);
    }
    updateCategory(category: Category,idx: number):boolean {
        let categories = this.getCategories();
        categories[idx]= category;
        localStorage.setItem('categories',JSON.stringify(categories));
        return SUCCESS;
    }

      deleteCategory(title: string) :boolean {
        let categoryIndex: number;
        for (var i = 0; i < this.categories.length; i++) {
            console.log(this.categories[i].title+"  "+title);
            if (this.categories[i].title === title) {
                categoryIndex = i;
            }
        }
        if (categoryIndex >= 0) this.categories.splice(categoryIndex, 1);
        localStorage.setItem('categories', JSON.stringify(this.categories));
        return SUCCESS;
    }

    addCategory(category: Category) :boolean{
        let categories = this.getCategories();
        if(categories.indexOf(category) === -1) {
            categories.push(category);
            localStorage.setItem('categories', JSON.stringify(categories));
            return SUCCESS
        } else {
            return ERROR;
        }
    }

     getWorkouts(): Array<WorkOut> {
        let workouts = new Array<WorkOut>();
        const existingWorkouts = localStorage.getItem('workouts');
       // console.log(existingWorkouts);
        if(null !== existingWorkouts) {
            workouts = JSON.parse(existingWorkouts);
        }
        return workouts;
    }

    deleteWorkout(idx: number): boolean {
        let workouts = this.getWorkouts();
        workouts.splice(idx, 1);
        localStorage.setItem('workouts', JSON.stringify(workouts));
        return SUCCESS;
    }
     saveWorkout(workout: WorkOut): boolean {
        let workouts = this.getWorkouts();
        if(workouts.filter(existingWorkout => existingWorkout.title === workout.title).length <= 0) {
            workouts.push(workout);
            localStorage.setItem('workouts', JSON.stringify(workouts));
            return SUCCESS;
        } else {
            return ERROR;
        }
    }
     updateWorkout(workout: WorkOut, idx: number): boolean {
        let workouts = this.getWorkouts();
        workouts[idx] = workout;
        localStorage.setItem('workouts', JSON.stringify(workouts));
        return SUCCESS;
    }

    getDailyWorkouts(): Array<DailyWorkoutPlan> {
        let dailyWorkouts = new Array<DailyWorkoutPlan>();
        const existingDailyWorkout = localStorage.getItem('dailyWorkouts');
        if(null !== existingDailyWorkout) {
            dailyWorkouts = JSON.parse(existingDailyWorkout);
        }
        return dailyWorkouts;
    }

    saveDailyWorkout(dailyWorkout: DailyWorkoutPlan): void {
        let dailyWorkouts = this.getDailyWorkouts();
        dailyWorkouts.push(dailyWorkout);
        localStorage.setItem('dailyWorkouts', JSON.stringify(dailyWorkouts));
    }

    updateDailyWorkout(workoutEntry: DailyWorkoutPlan): void {
        let dailyWorkouts = this.getDailyWorkouts();
        let index = dailyWorkouts.findIndex(existingDailyWorkout => {
           return existingDailyWorkout.workoutId === workoutEntry.workoutId
            && existingDailyWorkout.startDate === workoutEntry.startDate
            && existingDailyWorkout.startTime === workoutEntry.startTime
        });

        if(index >= 0) {
            dailyWorkouts[index] = workoutEntry;
            localStorage.setItem('dailyWorkouts', JSON.stringify(dailyWorkouts));
        }
    }

    static handleError(error: Response) {
        console.log(error);
        return Observable.throw(error || 'Server error');
    }
}
